
function showMessage() {
    alert("I wasn't looking for anything at all when I meet you actually I wasn't planning falling for anyone so soon but then you came into may life and that was it I guess things just happened I found you and I find myself wanting so spend more time with you it's was simple and easy but I guess that's how best relationships start your not looking for anything and then suddenly you realize u have something, something worth keeping. Lately I realized that i'm being mean for that something worth keeping and I sencerely apologize. I hope even with those mistakes that I've done you still find me as your safe home or your pahinga. Stay safe bebi Iloveyou:3");
}
